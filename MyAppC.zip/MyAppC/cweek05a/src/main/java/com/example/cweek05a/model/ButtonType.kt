package com.example.cweek05a.model

enum class ButtonType {
    ICON, BADGE, EMOJI
}